package com.app.core.pojos;

public class AuthorBookMap {
	private Integer authorId;
	private Book book;
	
	public AuthorBookMap() {
		// default const
	}

	public Integer getAuthorId() {
		return authorId;
	}

	public void setAuthorId(Integer authorId) {
		this.authorId = authorId;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}
	
	
}
