import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-author-home',
  templateUrl: './author-home.component.html',
  styleUrls: ['./author-home.component.css']
})
export class AuthorHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
